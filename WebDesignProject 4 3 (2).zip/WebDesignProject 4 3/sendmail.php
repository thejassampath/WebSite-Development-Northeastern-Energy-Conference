<?php 

include "email.php";

$testEmail= new email;
$from = 'thejassampath@gmail.com';
$sendTo ='thejassampath@gmail.com' ;
$subject='email';
$bodyHead='hi';
$bodyMain='sdsdsd';
$bodyEnd='Thanksksk';
$filePath='C:';
$fileName='/THEJAS.pdf';
if($testEmail->emailWithAttach($from,$sendTo,$subject,$bodyHead,$bodyMain,$bodyEnd,$filePath,$fileName)){
	
	echo "Email send successfull";
	
}else{
	
	echo"failed";
	
}
?>

