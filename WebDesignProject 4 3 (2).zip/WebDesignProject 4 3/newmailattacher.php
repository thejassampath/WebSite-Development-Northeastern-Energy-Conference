
<?php  

		$email = $_POST['email'];
require("class.phpmailer.php"); // path to the PHPMailer class
 
$mail = new PHPMailer();  

 
$mail->IsSMTP();  // telling the class to use SMTP
$mail->Mailer = "smtp";
$mail->Host = "ssl://smtp.gmail.com";
$mail->Port = 465;
$mail->SMTPAuth = true; // turn on SMTP authentication
$mail->Username = "thejassampath@gmail.com"; // SMTP username
$mail->Password = "beat2690#"; // SMTP password 
 
$mail->From     = "thejassampath@gmail.com";
$mail->FromName = "Support Team";
$mail->AddAddress($email);  
 
$mail->Subject  = "Energy Conference 2016 Invitation";
$mail->Body     = "Hi PFA the invitation of the Energy Conference Looking forward to meet you all 
You can make you of this link to plan yourself ahead of the conference on the events which you are planning to attend   http://localhost/WebDesignProject%204%203/eventToDoList.html";
$mail->WordWrap = 50;  
 


$mail->AddAttachment("mailattachment.png");      // attachment

if(!$mail->Send()) {
echo 'Message was not sent.';
echo 'Mailer error: ' . $mail->ErrorInfo;
} else {
   header("Location: newUserRegistration.html");
}

?>





