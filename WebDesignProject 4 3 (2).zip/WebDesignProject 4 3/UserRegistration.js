
'use strict';
var userreg = angular.module("userreg", [])
userreg.controller("userController", function($scope,$http) {
	/* 
	 $scope.getItem=function(){  
  $http.post("angulartest.php").success(function(data){
        $scope.blogpostfromtable = data;
  $scope.media={imagepath: "thumb.jpg"};
       });
  }; */
 
});

userreg.directive("passwordStrength", function(){
    return {        
        restrict: 'A',
        link: function(scope, element, attrs){                    
            scope.$watch(attrs.passwordStrength, function(value) {
                console.log(value);
                if(angular.isDefined(value)){
                    if (value.length > 8) {
                        scope.strength = 'strong';
                    } else if (value.length > 3) {
                        scope.strength = 'medium';
                    } else {
                        scope.strength = 'weak';
                    }
                }
            });
        }
    };
});







var app = angular.module('myApp', []);

app.controller('AppCtrl', function($scope){    

});

app.directive("passwordStrength", function(){
    return {        
        restrict: 'A',
        link: function(scope, element, attrs){                    
            scope.$watch(attrs.passwordStrength, function(value) {
                console.log(value);
                if(angular.isDefined(value)){
                    if (value.length > 8) {
                        scope.strength = 'strong';
                    } else if (value.length > 3) {
                        scope.strength = 'medium';
                    } else {
                        scope.strength = 'weak';
                    }
                }
            });
        }
    };
});