var mainApp = angular.module("mainApp", [])
mainApp.controller("blogController", function($scope,$http) {
	
	$scope.call=function(){
// Load all available items 
$scope.blog=efefef;
		alert("hi");
	};
 
});
