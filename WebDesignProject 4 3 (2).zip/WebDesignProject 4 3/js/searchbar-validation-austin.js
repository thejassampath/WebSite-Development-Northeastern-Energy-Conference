function grabSearch() {

    var search = document.getElementById('srch-term').value;
    if (search === "Search" || search === "") {
        alert("Please enter something to search");
    }
}