var mainApp = angular.module("mainApp", [])
mainApp.controller("blogController", function($scope,$http) {
	
	 $scope.getItem=function(){  
  $http.post("angulartest.php").success(function(data){
        $scope.blogpostfromtable = data;
  $scope.media={imagepath: "thumb.jpg"};
       });
  };
 
});
