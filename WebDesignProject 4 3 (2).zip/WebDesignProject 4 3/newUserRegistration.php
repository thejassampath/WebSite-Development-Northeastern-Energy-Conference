
<!DOCTYPE html>
<html lang="en" >
<head>
  <title>Bootstrap Case</title>
  <meta charset="utf-8">
 <!--  -->
  <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
    <link rel="stylesheet" href="main.css">
	

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
  
  <script src = "http://ajax.googleapis.com/ajax/libs/angularjs/1.3.14/angular.min.js"></script>
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
<link href="EnergyConference.css" rel="stylesheet" />
<link href="panel.css" rel="stylesheet" />
  <script src = "EnergyConferenceAngularJS.js"></script>


	 
</head>
<body>

  <!--  BODY PAGE CONTENT -->
<!-- navigation panel -->
<div class="container" ng-app = "mainApp" ng-controller = "blogController" ng-init="getItem()">
<div class="container">
<div class="row">
<div class="col-sm-6">
<div id="nucoe-logo">
              <a href="http://www.coe.neu.edu/" rel="home" title="Home"><img class="logo" src="http://www.coe.neu.edu/sites/all/themes/nucoe/images/nucoe-logo.jpg" alt=" logo" title=" Home"></a> 
            </div>
			</div>
			<div class="col-sm-6">
			<a><img class="ess" src="Drawing.png" style="float:right;margin: 27px 0;" alt=" logo"></a> 
			
</div>
</div>

	
	
	
	<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
    
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
      <li><a href="EnergyConference.html">HOME</a></li>
      	
	 <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">PANELS<span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="Sustainablebuildings.html">SUSTAINABLE BUILDINGS</a></li>
			 <li role="separator" class="divider"></li>
            <li><a href="Thermal.html">THERMAL POWER</a></li>
			 <li role="separator" class="divider"></li>
            <li><a href="#">CLEANPOWER</a></li>
            <li role="separator" class="divider"></li>
            <li><a href="cleanairpolicy.html">POLICY CLEAN AIR</a></li>
            <li role="separator" class="divider"></li>
            <li><a href="technology.html">TECHNOLOGY INNOVATION</a></li>
          </ul>
        </li>
		
       <li><a href="#aboutus">ABOUT US</a></li>
		<li><a href="#agenda">AGENDA</a></li>
		<li><a href="Team.html">ORGANIZING TEAM</a></li>
		<li><a href="#sponsors">SPONSORS</a></li>
		<li><a href="EventsMap.html">EVENT LOCATION</a></li>
		<li><a href="#">BUY TICKETS</a></li>
      </ul>
    
    </div>
  </div>
</nav>
  
	</div>
	
	
	
	<div class="container">

	  
	  <form>
  <fieldset class="form-group">
    <label for="exampleInputEmail1">Email address</label>
    <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Enter email">
    <small class="text-muted">We'll never share your email with anyone else.</small>
  </fieldset>
  <fieldset class="form-group">
    <label for="exampleInputPassword1">Password</label>
    <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
  </fieldset>
  <fieldset class="form-group">
    <label for="exampleSelect1">Example select</label>
    <select class="form-control" id="exampleSelect1">
      <option>1</option>
      <option>2</option>
      <option>3</option>
      <option>4</option>
      <option>5</option>
    </select>
  </fieldset>
  <fieldset class="form-group">
    <label for="exampleSelect2">Example multiple select</label>
    <select multiple class="form-control" id="exampleSelect2">
      <option>1</option>
      <option>2</option>
      <option>3</option>
      <option>4</option>
      <option>5</option>
    </select>
  </fieldset>
  <fieldset class="form-group">
    <label for="exampleTextarea">Example textarea</label>
    <textarea class="form-control" id="exampleTextarea" rows="3"></textarea>
  </fieldset>
  <fieldset class="form-group">
    <label for="exampleInputFile">File input</label>
    <input type="file" class="form-control-file" id="exampleInputFile">
    <small class="text-muted">This is some placeholder block-level help text for the above input. It's a bit lighter and easily wraps to a new line.</small>
  </fieldset>
  <div class="radio">
    <label>
      <input type="radio" name="optionsRadios" id="optionsRadios1" value="option1" checked>
      Option one is this and that&mdash;be sure to include why it's great
    </label>
  </div>
  <div class="radio">
    <label>
      <input type="radio" name="optionsRadios" id="optionsRadios2" value="option2">
      Option two can be something else and selecting it will deselect option one
    </label>
  </div>
  <div class="radio disabled">
    <label>
      <input type="radio" name="optionsRadios" id="optionsRadios3" value="option3" disabled>
      Option three is disabled
    </label>
  </div>
  <div class="checkbox">
    <label>
      <input type="checkbox"> Check me out
    </label>
  </div>
  <button type="submit" class="btn btn-primary">Submit</button>
</form>
	<footer class="container-fluid well">
  <hr />
  

 <hr>
 <div class="row">
        <div class="text-center center-block">
           
                <a href="https://www.facebook.com/NUEnergyConference?fref=ts"><i id="social-fb" class="fa fa-facebook-square fa-3x social"></i></a>
	            <a href="https://twitter.com/nuessboston"><i id="social-tw" class="fa fa-twitter-square fa-3x social"></i></a>
	        
	            <a href="mailto:sampathkumar.t@husky.neu.edu"><i id="social-em" class="fa fa-envelope-square fa-3x social"></i></a>
                    <p class="center-block">Copyright: NorthEastern University <BR> Energy Systems Society</p>
</div>
</div>
    <hr>
 
</footer>
      </div>


    
 </div>
    
    
    
<!-- footer -->

<!-- /footer -->

  <!-- attach JavaScripts -->
  <script>
$( "button" ).click(function() {
  $( "p" ).slideToggle( "slow" );
});
</script>




</body>
</html>